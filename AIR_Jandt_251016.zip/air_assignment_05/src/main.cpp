/*
 * Daniel Vazquez
 * Aritificial Intelligence for Robotics
 * SS 2016
 * Assignment 5
 *
 * main.cpp
 * */

#include "environment.hpp"


int main(int arc, char* argv[])

{
    Environment anEnvironment;
    anEnvironment.run();
    return 1;
}
